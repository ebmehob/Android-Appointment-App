package com.example.lab3

import com.example.lab3.data.local.Appointment

data class Wrapper(val record: List<Appointment>)
